from .data import *


def main():
    return


if __name__ == "__main__":
    main()
