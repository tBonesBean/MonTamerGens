from mongens import *
from mongens.data.data import *


initialized = True


def main():
    pass


if __name__ == "__main__":
    main()
