from typing import Dict, List

# -- Baseline stats (can override per species later, after Elements do # there thing and populate stat boxes)

BASE_STATS: Dict[str, int] = {"HP": 100, "ATK": 50, "DEF": 50, "SPATK": 50, "SPDEF": 50, "SPD": 50, "ACC": 95, "EVA": 5, "LUCK": 10}

# ___________________________________________________________________________________

SEED_TYPES: List[str] = [
    "Geomorph", "Beast", "Aquatic", "Cryoform", "Pugilist", "Insectoid", "Mythic", "Electric", "Verdant", "Avian", "Dread", "Pyro", "Toxic", "Ancient",
    "Psychokinetic", "Neutral", "Colorless"
]

INCOMPATIBLE_TYPE_PAIRS = {
    frozenset(["Pyro", "Aquatic"]),
    frozenset(["Pyro", "Cryoform"]),
    frozenset(["Electric", "Geomorph"]),
}
# Each main type gets a baseline “body plan” bias.
# These are applied on top of BASE_STATS *before* mutagens.

FORMS_BY_TYPE: Dict[str, List[str]] = {
    "Geomorph": [
        "Gorgonopsid", "Stone Golem", "Earth Elemental", "Rock Hyrax", "Basilisk Lizard", "Gargoyle", "Moai-Stone Colossus", "Giant Anteater", "Trilobite",
        "Komodo Dragon", "Khalkotauroi", "Stoneback Tortoise Beast", "Obsidian Sandwyrm"
    ],
    "Beast": [
        "Warthog", "Smilodon", "Minotaur", "Wolverine", "Wild Boar", "Mastiff-like Dire Hound", "Pangolin", "Tasmanian Tiger", "Hellhound", "Baboon", "Barong",
        "Nandi Bear", "Calydonian Boar"
    ],
    "Aquatic": [
        "Dugong", "Giant Oarfish", "Dunkleosteus", "Kraken", "Axolotl", "Blue Dragon Sea Slug", "Mosasaur", "Naiad", "Sailfish", "Coelacanth", "Kelpie",
        "Adaro", "Cetus"
    ],
    "Cryoform": [
        "Polar Bear", "Woolly Rhinoceros", "Wendigo", "Snowy Owl", "Ice Elemental", "Caribou", "Yeti", "Arctic Fox", "Megaloceros", "Narwhal", "Jotunn",
        "Snow Kirin", "Ice Wyrmling Drake"
    ],
    "Pugilist": [
        "Kangaroo", "Mantis Shrimp", "Gorilla", "Boxing Beetle", "Red Kangaroo Rat-boxing Monster", "Secretary Bird", "Harpy", "Cassowary", "Thylacoleo",
        "Chimpanzee", "Stone-Fist Gargant", "Pummeler Homunculus", "Oni Boxer"
    ],
    "Insectoid": [
        "Tarantula Hawk", "Titan Beetle", "Meganeura", "Antlion", "Mothman", "Horseshoe Crab", "Coconut Crab", "Grylloblattid", "Giant Isopod",
        "Praying Mantis", "Scarab Guardian", "Unkcela", "Trilobite Colossus"
    ],
    "Mythic": [
        "Griffin", "Kitsune", "Banshee", "Thunderbird", "Nemean Lion", "Leviathan", "Qilin", "Selkie", "Jorōgumo", "Phoenix", "Mapinguari", "Hippogriff",
        "Tikbalang"
    ],
    "Electric": [
        "Electric Eel", "Storm Elemental", "Thundering Roc", "Platypus", "Torpedo Ray", "Ball Lightning Sprite", "Scintillant Tree Frog", "St. Elmo’s Fire",
        "Electric Catfish", "Scintillating Beetle", "Thunderbird Whelp", "Raiju", "Volt Seraph"
    ],
    "Verdant": [
        "Dryad", "Nepenthes Pitcher Beast", "Ent", "Yew Tree Spirit", "Mandrake", "Venus Flytrap", "Wollemi Pine Dryosaur", "Bramble Golem", "Baobab Tortoise",
        "Moss-Lurker Sprite", "Kodama", "Thorn Hydra", "Spriggan"
    ],
    "Avian": [
        "Shoebill", "Archaeopteryx", "Roc", "Harpy Eagle", "Kiwi", "Hoatzin", "Takahē", "Terror Bird", "Lyrebird", "Red-crowned Crane", "Firefoot Heron",
        "Bennu", "Storm Petrel Titan"
    ],
    "Dread": [
        "Wraith", "Shadow Hound", "Nightgaunt", "Chupacabra", "Ghoul", "Barghest", "Lurking Mirefiend", "Blemmyes", "Mare", "Dullahan", "Draugr", "Nachtkrapp",
        "Shadow Lamia"
    ],
    "Pyro": [
        "Salamander", "Fire Jinn", "Ifrit", "Ash Drake", "Volcanic Worm", "Fire Beetle", "Ember Lion", "Solifuge", "Pyrosaurus", "Firebird", "Magma Salamander",
        "Zhurong Beast", "Fire Jotunn"
    ],
    "Toxic": [
        "Blue-ringed Octopus", "Stonefish", "Inland Taipan", "Poison Dart Frog", "Gila Monster", "Boomslang", "Box Jellyfish", "Deathstalker Scorpion",
        "Portuguese Man o’ War", "Hooded Pitohui", "Wyvern Basilisk", "Tatzelwurm", "Nagual Serpent Shade"
    ],
    "Ancient": [
        "Anomalocaris", "Titanoboa", "Andrewsarchus", "Plesiosaur", "Ammonite", "Saurosuchus", "Hallucigenia", "Protostega", "Giant Ground Sloth",
        "Quetzalcoatlus", "Diprotodon", "Dunkleoceratid", "Uintatherium"
    ],
    "Psychokinetic": [
        "Cerebellid Wisp", "Astral Jelly", "Homunculus", "Tarsier", "Mind Flayer", "Dream-Eater Tapir Spirit", "Spectral Owl", "Neurophage Shade",
        "Deep-Thought Squid", "Oracle Serpent", "Alkonost", "Astral Lynx", "Baku"
    ],
    "Neutral": [
        "Slime Blob"
    ],
    "Colorless": [
        "Sphinx"
    ]
}
# Each main type gets a baseline “body plan” bias.
# These are applied on top of BASE_STATS *before* mutagens.

SEEDTYPE_ATTR = {
    "Beast": {"mul": {"DEF": 1.16, "SPD": 1.2, "ATK": 1.2}, "add": {}, "tags": ["Resist:", "Weak:Venomous"]},
    "Ancient": {"mul": {"HP": 1.26, "SPDEF": 1.18, "ATK": 1.15, "DEF": .95}, "add": {}, "tags": ["Resist:Mythic", "Weak:Cosmic"]},
    "Electric": {"mul": {"SPD": 1.15, "SPATK": 1.22}, "add": {}, "tags": ["Resist:Electric", "Weak:Terra"]},
    "Toxic": {"mul": {"SPATK": 1.2, "DEF": 1.1, "HP": 1.2}, "add": {}, "tags": ["DOT:Poison", "Weak:Radiant"]},
    "Aquatic": {"mul": {"SPDEF": 1.22, "ATK": 1.21}, "add": {}, "tags": ["Resist:?", "Weak:Electric"]},
    "Pyro": {"mul": {"SPATK": 1.28, "DEF": 1.15, "SPD": 1.18}, "add": {}, "tags": ["DOT:Burn", "Weak:Aquatic"]},
    "Dread": {"mul": {"SPDEF": 1.22, "SPATK": 1.18, "DEF": .94}, "add": {}, "tags": ["OnCrit:Leech", "Weak:Radiant"]},
    "Mythic": {"mul": {"SPATK": 1.15, "LUCK": 1.30, "HP": 1.3}, "add": {}, "tags": ["Pierce:Barrier", "Weak:Obsidian"]},
    "Cryoform": {"mul": {"SPDEF": 1.12, "LUCK": 1.12}, "add": {}, "tags": ["Regen:Night", "Weak:Radiant"]},
    "Verdant": {"mul": {"HP": 1.2, "SPDEF": 1.28, "SP": .94, "ATK": 1.12}, "add": {}, "tags": ["Regen:Terrain", "Weak:Volcanic"]},
    "Geomorph": {"mul": {"DEF": 1.22, "SPDEF": 1.15, "ATK": 1.15, "SPATK": .90}, "add": {}, "tags": ["Ambush:Burrow", "Weak:Pugilist", "Weak:Aquatic"]},
    "Psychokinetic": {"mul": {"SPD": 1.2, "SPATK": 1.26, "SPDEF": 1.2, "HP": .93}, "add": {}, "tags": ["MultiHit:Kinesis", "Weak:Dread"]},
    "Avian": {"mul": {"SPD": 1.16, "ATK": 1.22, "HP": 1.05, "SPDEF": 1.1, "DEF": .98}, "add": {}, "tags": ["Evade:Terrain", "Ability:FlyingMount"]},
    "Insectoid": {"mul": {"DEF": 1.18, "ATK": 1.18, "SPD": 1.4, "SPDEF": 1.21}, "add": {}, "tags": ["Guard:Stagger", "Weak:Chaos"]},
    "Pugilist": {"mul": {"SPD": 1.18, "ATK": 1.22, "SPATK": 0.96}, "add": {}, "tags": []},
    "Neutral": {"mul": {}, "add": {}, "tags": []},
    "Colorless": {"mul": {}, "add": {}, "tags": []},
}

MAJOR_MODS = {
    # -- TO BE CONVERTED TO MAIN TYPES. REFERENCED IN CREATURE_POOLS.PY; MAINTAINS SAME AUTHORITY TO CANONICALLY BUFF/DEBUFF, APPLY TAGS, TRAITS, WEAKNESSES,
    # AND ADVANTAGES --#

    "Terran": {"mul": {"DEF": 1.15, "HP": 1.10}, "tags": ["Resist:Stormforged", "Weak:Venomous"]},
    "Glacial": {"mul": {"SPDEF": 1.15, "HP": 1.15}, "tags": ["Resist:Frostbound", "Weak:Tempest"]},
    "Charged": {"mul": {"SPD": 1.15, "SPATK": 1.10}, "tags": ["Resist:Electric", "Weak:Terra"]},
    "Venomous": {"mul": {"SPATK": 1.12, "SPD": 1.15}, "tags": ["DOT:Poison", "Weak:Radiant"]},
    "Radiant": {"mul": {"SPATK": 1.12, "ACC": +5}, "tags": ["Cure:Blind", "Weak:Shadow"]},
    "Shade": {"mul": {"SPD": 1.10, "SPATK": 1.08}, "tags": ["OnCrit:Leech", "Weak:Radiant"]},
    "Astral": {"mul": {"SPATK": 1.15, "LUCK": 1.10}, "tags": ["Pierce:Barrier", "Weak:Obsidian"]},
    "Solar": {"mul": {"ATK": 1.08, "SPATK": 1.08, "HP": 1.05}, "tags": ["Regen:Day", "Weak:Chaos"]},
    "Lunar": {"mul": {"SPDEF": 1.12}, "tags": ["Regen:Night", "Weak:Solar"]},
    "Chaos": {"mul": {"HP": .92, "ATK": 1.16, "SPATK": 1.16, "SPD": .96}, "tags": ["Random:Proc", "Weak:Ironclad"]},
    "Subterran": {"mul": {"DEF": 1.14, "ATK": 1.08}, "tags": ["Ambush:Burrow", "Weak:Astral"]},
    "Tempest": {"mul": {"SPD": 1.12, "ATK": 1.05}, "tags": ["MultiHit:Storm", "Weak:Crystalline"]},
    "Armored": {"mul": {"DEF": 1.12, "SPDEF": 1.1}, "tags": ["Guard:Stagger", "Weak:Shadow"]},
    "Volcanic": {"mul": {"SPATK": 1.10, "DEF": 1.05}, "tags": ["Burn:Contact", "Weak:Tempest"]},
    "Atmos": {"mul": {"SPD": 1.15}, "tags": ["Evade:Aerial", "Weak:Electric"]},
    "OceanFloor": {"mul": {"SPD": 1.12, "SPATK": 1.05}, "tags": ["FirstStrike:Water", "Weak:Solar, Verdant"]},
    "Telepathic": {"mul": {"LUCK": 1.10, "SPATK": 1.06}, "add": {"ACC": +1}, "tags": ["Pierce:Mind", "Weak:Ironclad"]},
    "Mistwoven": {"mul": {"SPD": 1.06, "SPDEF": 1.04}, "add": {"EVA": +2}, "tags": ["Fog:Field", "Weak:Radiant"]},
    "Riftbound": {"mul": {"SPD": 1.08}, "add": {"ACC": +1}, "tags": ["Blink:Short", "Weak:Obsidian"]},
    "Sensei": {"mul": {}, "add": {}, "tags": []}
    # keep others neutral (they still exist as “major” flavor)
}

MINOR_MODS = {
    "ThornArmor": {"mul": {"DEF": 1.1}, "tags": ["Thorns:Light"]},
    "SaltSpire": {"mul": {"SPDEF": 1.1}, "tags": ["Resist:Water"]},
    "CavernDweller": {"mul": {"SPDEF": 1.1, "HP": 1.2}, "tags": ["Accuracy:Dark"]},
    "DuneSurfer": {"mul": {"SPD": 1.1}, "tags": ["Initiative:Sand"]},
    "EmberFormed": {"mul": {"SPATK": 1.1}, "tags": ["Ignite:Low"]},
    "CanopyProtected": {"mul": {"SPD": 1.1}, "tags": ["Evasion:Height"]},
    "TurbulentFlow": {"mul": {"SPD": 1.1}, "tags": ["Action:Flow"]},
    "BergSurfer": {"mul": {"SPDEF": 1.1}, "tags": ["Slide:Ice"]},
    "SuperOrbital": {"mul": {"SPATK": 1.1}, "tags": ["Curse:Minor"]},
    "Stormborn": {"mul": {"ATK": 1.1}, "tags": ["Call:Storm"]},
    "VineGatherer": {"mul": {"SPATK": 1.1, "SPD": .92}, "tags": ["Leech:Minor"]},
    "Runestone": {"mul": {"SPATK": 1.1}, "tags": ["RuneSlots:+1"]},
    "Grovebound": {"mul": {"HP": 1.1}, "tags": ["Heal:Terrain"]},
    "Sunbaked": {"mul": {"ATK": 1.1}, "tags": ["DayBoost"]},
    "Tanglethorn": {"mul": {"DEF": 1.1}, "tags": ["Snare:Low"]},
    "CloudShaper": {"mul": {"SPD": 1.1}, "tags": ["Leap:Aerial"]},
    "StarChild": {"mul": {"LUCK": 1.1}, "tags": ["Crit:Starlit"]},
    "Driftwood": {"mul": {"HP": 1.02, "SPDEF": 1.02}, "tags": ["Float:Water"]},
    "Shaleheart": {"mul": {"DEF": 1.04}, "tags": ["Resist:Blunt"]},
    "Petrastone": {"mul": {"DEF": 1.04, "HP": 1.02}, "tags": ["Slow:Minor"]},
    "Feralwind": {"mul": {"SPD": 1.03, "ATK": 1.02}, "tags": ["Howl:Pack"]},
    "Shadowshroud": {"mul": {"SPD": 1.03}, "tags": ["Veil:Dark"]},
    "DuneSpeak": {"mul": {"SPD": 1.02, "ATK": 1.1}, "tags": ["Crit:Sand"]},
    "BlackIce": {"mul": {"SPDEF": 1.04}, "tags": ["Slide:Ice"]},
    "DeepRoot": {"mul": {"HP": 1.07, "SPATK": 1.03}, "tags": ["Root:Terrain"]},
    "ThunderClap": {"mul": {"SPATK": 1.05}, "tags": ["Call:Storm"]},
    "OnyxCore": {"mul": {"DEF": 1.04, "HP": 1.02}, "tags": ["Resist:Blunt"]},
    "BioLuminescent": {"mul": {"LUCK": 1.05}, "add": {}, "tags": ["Glow:Dark", "Lure:Shallow"]},
    "ArcheoAnomaly": {"mul": {"ATK": 1.08, "SPDEF": 1.06}, "add": {"EVA": +1}, "tags": ["Sentience:Inconsistent"]},
}

UTILITY_MODS = {
    "Age<UNKNOWN>": {"exp_mult": 1.10, "loot_mult": 1.15, "tags": ["Lore:Gates"]},
    "NaturalLeader": {"ally_buff": {"ATK": 1.12, "HP": 1.20}, "exp_share_bonus": 0.20, "tags": ["VeteranPresence", "BattleCry"]},
    "Diviner": {"minimap_reveal": True, "tags": ["Reveal:Secrets"]},
    "InnateProtector": {"ally_buff": {"DEF": 1.08}, "aggro_redirect": True},
    "DevotedGuard": {"ally_guard_proc": 0.15, "tags": ["Intercept"]},
    "Empath": {"ally_heal_on_crit": 0.10, "tags": ["Soothing"]},
    "KeeperOfKeys": {"unlock_tags": ["Gate:Runic", "Door:Sealed"]},
    "CosmicInterpreter": {"identify_rates": 0.25, "tags": ["Identify:Rare"]},
    "TruthSpeaker": {"npc_dialog_plus": True, "tags": ["Diplomacy"]},
    "Improbable": {"rng_luck_bias": 0.10, "tags": ["WildProcs"]},
    "Seeker": {"track_rare_spawns": True, "track_rare_loot": True, "tags": ["Tracker", "TreasureHunter"]},
    "Homeless": {"camp_bonus": {"Heal%": 0.05, "exp_mult": 1.15}, "tags": ["Wanderer"]},
    "Omnipresent": {"fast_travel_nodes": True},
    "Superpositional": {"double_rolls": ["Loot", "Crit"], "tags": ["Quantum"]},
    "BattleDisruptor": {"enemy_opening_debuff": {"SPD": 0.90, "ACC": -8}, "tags": ["Disorient"]},
    "DedicatedCoach": {"ally_exp_mult": 1.15},
    "Humanitarian": {"loot_to_supplies": 0.20, "tags": ["ConvertLoot"]},
    "TrainingPartner": {"spar_exp_bonus": 0.20},
    "MagneticAura": {"pull_items_radius": 12, "pull_hidden_radius": 8, "tags": ["Magnetism"]},
    "SymbioticNature": {"field_heal_ticks": 0.05, "ally_heal_ticks": 0.02, "tags": ["HealingAura"]},
    "SecretKeeper": {"npc_dialog_plus": True, "minimap_reveal": True, "tags": ["HiddenPaths"]},
    "NearExtinction": {"self_revive": True, "identify_fossils": True, "identify_eggs": True}
}

ALL_ELEMENTS = [SEED_TYPES, MAJOR_MODS, MINOR_MODS, UTILITY_MODS]

# --Definitely dictates appearance and contributes to substantiating game world, likely will become factor when randomizing hidden traits, moves/attacks,
# special abilities,
# etc. --#
TRAITS_LIST = [
    ["Multiple Tails", "Trident", "Steps Make Subtle Sparks"],
    ["Oversized Crown", "Gills", "Solar-Phobia"],
    ["Hovers When It Rains", "Stamp Collection", "Persistent Hallucinations"],
    ["High-Fashion", "Herbivore", "Receives Cosmic Messages"],
    ["Bipedal", "Wears Heavy Amulets", "Terrible Hay Fever"],
    ["Face Obsured By Pollution", "Equipped With Satellite Dish", "Amnesia"],
    ["Full Plate Armor", "Builds Nest With Shells", "Nocturnal"],
    ["Glowing Freckles", "Compass That Hums", "Allergic To Moonlight"],
    ["Translucent Skin", "Pocket Sundial", "Speaks In Echoes"],
    ["Feathered Arms", "Ancient Coin Collection", "Dreams Predict Rainfall"],
    ["Cracked Porcelain Mask", "Pet Cloud", "Forgets Own Reflection"],
    ["Luminescent Veins", "Bone Flute", "Haunted By Laughter"],
    ["One Glass Eye", "Floating Lantern Companion", "Immune To Cold"],
    ["Spiraled Horns", "Mechanical Heart", "Whispers To Stones"],
    ["Mismatched Eyes", "Cursed Locket", "Leaves Frost Footprints"],
    ["Tattooed Constellations", "Hourglass Pendant", "Never Casts A Shadow"],
    ["Metallic Hair", "Pocket Full Of Sand", "Understands Every Language But Their Own"],
    ["Webbed Fingers", "Obsidian Dagger", "Allergic To Sunlight"],
    ["Crystalline Spine", "Enchanted Scarf", "Remembers Other Lives"],
    ["Ashen Skin", "Compass That Points To Danger", "Hums When Nervous"],
    ["Cape Of Smoke", "Cracked Monocle", "Can’t Cross Running Water"],
    ["Glimmering Scales", "Silver Whistle", "Haunted By A Melody"],
    ["Turtle Shell Hat", "Pocket Mirror That Lies", "Collects Fallen Stars"],
    ["Antler Crown", "Broken Pocket Watch", "Voice Echoes Twice"],
    ["Moss-Covered Shoulders", "Golden Key", "Never Sleeps On Full Moons"],
    ["Glowing Pupils", "Ancient Scroll", "Sneezes Sparks"],
    ["Tinted Astronaut Helmet", "Hourglass Tattoo", "Can’t Be Photographed"],
    ["Sentient Tail", "Compass Of Bone", "Allergic To Laughter"],
    ["Cracked Halo", "Vial Of Mist", "Speaks To Insects"],
    ["Stone Skin", "Silver Ring That Hums", "Forgets Faces Instantly"],
    ["Shimmering Icy Breath", "Always Reading Seer Bones", "Terrified Of Mirrors"],
    ["Branch-Like Fingers", "Crystal Monocle", "Dreams In Color Only"],
    ["Top Hat With Feather", "Infinity Symbol Earrings", "Can’t Lie"],
    ["Metal Jaw And Shoulderplates", "Charm Bracelet Of Teeth", "Floats When Calm"],
    ["Opal Eyes", "Cursed Violin", "Allergic To Salt"],
    ["Scaled Neck", "Compass That Spins Wildly", "Voice Attracts Moths"],
    ["Glowing Body Pattern", "Broken Crown", "Remembers Every Sound Ever Heard"],
    ["Smoke Hair", "Hourglass Heart", "Can’t Touch Iron"],
    ["Shadow Has Massive Wings", "Silver Coin", "Speaks To Reflections"],
    ["Glowing Fingertips", "Pocket Flame", "Terrified Of Silence"],
    ["Horned Silhouette", "Glass Bottle Of Whispers", "Never Ages"],
    ["Oversized Beak", "Holds Pouches Of Secret Contents", "Allergic To Rain"],
    ["Crystal Antlers", "Golden Thread", "Can’t Dream"],
    ["4 Arms", "Hourglass Of Sand", "Longs To Be Back Among The Stars"],
    ["Glowing Scars", "Silver Bell", "Haunted By Footsteps"],
    ["Porcelain Mask", "Compass That Hums Softly", "Can’t Cry"],
    ["Feathered Cloak", "Pocket Of Ashes", "Reliably Full Of Joy"],
    ["Stone Horns", "Hourglass Pendant", "Speaks In Riddles"],
    ["Glowing Eyes", "Silver Dagger", "Can’t Remember Names"],
    ["Cracked Skin", "Compass That Points Home", "Laughs At Thunder"],
    ["Shadowed Face", "Vial Of Tears", "Allergic To Gold"],
    ["Glimmering Hair", "Pocket Watch That Ticks Backward", "Can’t Whistle"],
    ["Meditating Body Position", "Silver Coin", "Dreams Of Drowning"],
    ["Crystal Teeth And Claws", "Tail Glows When In Danger", "Sees Prophecy In Flames"],
    ["Unusually Long Tail", "Hourglass Tattoo", "Can’t See Stars"],
    ["Glowing Veins", "Pocket Mirror", "Speaks To Shadows"],
    ["Horned Brow", "Oversized Bandit Mask", "Can Be Lured By Music"],
]

COL_TRAITS = [  # -- Much easier to mass generate random traits as triplets, without sacrificing positional integrity in transposed orientation shown below --#
    [
        "Multiple Tails", "Oversized Crown", "Hovers When It Rains", "Bipedal", "Face Obsured By Pollution", "Full Plate Armor", "Glowing Fangs",
        "Translucent Skin",
        "Walks on Hands due to Curious Environmental Adaptation", "Cracked Porcelain Mask", "Luminescent Veins", "One Glass Eye", "Spiraled Horns",
        "Mismatched Eyes",
        "Tattooed Constellations", "Metallic Hair", "Webbed Fingers", "Crystalline Spine", "Ashen Skin", "Cape Of Smoke", "Glimmering Scales",
        "Turtle Shell Hat", "Antler Crown",
        "Top-heavy but Never Off-balance", "Glowing Pupils", "Tinted Astronaut Helmet", "Sentient Tail", "Cracked Halo", "Stone Skin", "Shimmering Icy Breath",
        "Branch-Like Fingers", "Top Hat With Feather", "Metal Jaw And Shoulderplates", "Opal Eyes", "Bipedal", "Bipedal", "Bipedal", "Glowing Body Pattern",
        "Hair Mysteriously Flows as if always Underwater", "Long fur looks like it's shifting the way it does when underwater", "Shadow Has Massive Wings",
        "Wings shimmer and move like a Mirage", "Antennae that act like Periscopes", "Sentiet Antennae", "Sentient Antlers", "Glowing Fingertips",
        "Only the Silhouette seems to have Giant Horns", "Oversized Beak", "Crystal Elk Antlers", "Four Extra Arms", "Glowing Scars", "Porcelain Mask",
        "Feathered Cloak",
        "Stone Horns", "Glowing Eyes", "Chestplate made of Caribou Antlers", "Shadowed Face", "Hair Changes Color to Indicate Mood", "Meditating Body Position",
        "Crystal Teeth And Claws", "Weaponized Tail", "Veins create Pulsating Glow of Random Colors every few seconds",
        "Dangerous, but Flightless, Wings that are used for Self-Defense", "Tail Glows When In Danger", "Bipedal",
        "Humanoid Shape while staying true to Natural Traits",
    ],
    [
        "Trident", "Gills", "Stamp Collection", "Equipped With Satellite Dish", "Builds Nest With Shells", "Compass That Hums", "Pocket Sundial",
        "Ancient Coin Collection",
        "Pet Cloud", "Bone Flute", "Floating Lantern Companion", "Mechanical Heart", "Obsidian Dagger", "Enchanted Scarf", "Compass That Points To Danger",
        "Cracked Monocle",
        "Broken Pocket Watch", "Golden Key", "Ancient Scroll", "Adorned with Bone Charms", "Eyes Made of Strange Mist",
        "Silver Ring That Identifies Nearby Ore",
        "Always Reading Seer Bones", "Crystal Monocle and Black Felt Tophat", "Charm Bracelet Of Teeth", "Cursed Violin", "Compass That Spins Wildly",
        "Broken Crown",
        "Pocket Flame", "Glass Bottle Of Whispers", "Holds Pouches Of Secret Contents", "Golden Thread", "Giant Hourglass containing Claws of Enemies",
        "Compass That Hums Softly",
        "Bottomless Pocket Of Ashes that's Constantly Spilling Over", "Silver Dagger", "Compass That Points Home", "Vial Of Tears",
        "Pocket Watch That Ticks Backward",
        "Silver Coin", "Oversized Bandit Mask", "Four Drumsticks but Nothing to Drum", "Steps Make Subtle Sparks",
    ],
    [
        "Solar-Phobia", "Persistent Hallucinations", "Receives Cosmic Messages", "Terrible Hay Fever", "Amnesia", "Nocturnal", "Allergic To Moonlight",
        "Speaks In Echoes",
        "Dreams Predict Rainfall", "Forgets Own Reflection", "Haunted By Laughter", "Immune To Cold", "Whispers To Stones", "Leaves Frost Footprints",
        "Never Casts A Shadow",
        "Understands Every Language But Their Own", "Allergic To Sunlight", "Remembers Past Lives", "Hums When Nervous", "Can’t Cross Running Water",
        "Haunted By A Melody",
        "Collects Fallen Stars", "Voice Echoes Twice", "Never Sleeps On Full Moons", "Sneezes Sparks", "Can’t Be Photographed", "Allergic To Laughter",
        "Speaks To Insects",
        "Forgets Faces Instantly", "Terrified Of Mirrors", "Dreams In Color Only", "Can’t Lie", "Floats When Calm", "Allergic To Salt", "Voice Attracts Moths",
        "Remembers Every Sound Ever Heard", "Can’t Touch Iron", "Speaks To Reflections", "Terrified Of Silence", "Never Ages", "Allergic To Rain",
        "Can’t Dream",
        "Longs To Be Back Among The Stars", "Haunted By Footsteps", "Can’t Cry", "Reliably Full Of Joy", "Speaks In Riddles", "Can’t Remember Names",
        "Laughs At Thunder",
        "Allergic To Gold", "Can’t Whistle", "Dreams Of Drowning", "Sees Prophecy In Flames", "Can’t See Stars", "Speaks To Shadows", "Can Be Lured By Music",
        "Herbivore"
    ]
]

TEMPERS_COUPLED: Dict[str, List[str]] = {
    "mood": [
        "Shy", "Bashful", "Hostile", "Wary", "Clever", "Aloof", "Warm", "Cold", "Guarded", "Friendly", "Suspicious", "Curious", "Gentle", "Arrogant", "Proud",
        "Humble", "Kind",
        "Cruel", "Generous", "Jealous", "Envious", "Patient", "Impatient", "Sensitive", "Indifferent", "Compassionate", "Cynical", "Trusting", "Distrustful",
        "Amiable",
        "Resentful", "Cheerful", "Irritable", "Sincere", "Devious", "Gracious", "Petty", "Tolerant", "Moody", "Outgoing", "Territorial", "Aggressive", "Immune",
        "Conceited",
        "Confident", "Wise", "Optimistic", "Lonely"
    ],
    "affinity": [
        "Selflessness", "Warmth", "Hostility", "Coyness", "Honor", "Glory", "Boldness", "Intellect", "Caution", "Suspicion", "Curiosity", "Gentleness",
        "Arrogance", "Pride",
        "Humility", "Kindness", "Cruelty", "Generosity", "Open-Mindedness", "Envy", "Patience", "Impatience", "Sensitivity", "Indifference", "Compassion",
        "Cynicism",
        "Trustfulness", "Distrust", "Amiability", "Resentment", "Cheerfulness", "Irritability", "Sincerity", "Deviousness", "Graciousness", "Pettiness",
        "Tolerance"
    ],
}

_ALL_HABITATS_RAW = [
    "Oldgrowth Marsh", "Misty Glades", "Thornveil Thicket", "Highlands", "Smoldering Flats", "Collapsed Magma Tubes", "Ancient Lavaflows", "Whispering Dunes",
    "Glass Caverns", "Obsidian Labyrinth", "Ashlands", "Mt. Thermallia", "Crystalline Cave", "Petrified Forest", "Glassy Caverns", "Skybridge Peaks",
    "Frozen Steppe", "Glass Desert", "Shattered Plateau", "Yittrosian Forest", "Thriving Reefs", "Sunless Abyss", "Alpine Lakes", "Moonlit Atolls",
    "Bioluminous Currents", "Violent Rapids", "Freshwater Springs", "Unyielding Cascades" "Ennoan Grasslands", "Alpine Slopes", "Lunaglow Plateau",
    "Riverlands", "Dayless Mosswood", "Still Tidepools", "Starfall Crater", "Celestial Spire", "Aurora Fields", "Echoing Grotto", "Astral Terrace",
    "Dread Catacombs", "Gloomfen Bogs", "AshGlass Tombs", "Darkmist Chasm", "Abandoned Wastes", "Power Plant", "Eroding Shipwreck", "Ghost Town",
    "Abandoned Village", "Concrete Jungle", "Rusted Plane Wreckage", "Wild Tundra", "Ice Caps", "Snowcapped Peaks", "Frigid Icefields",
    "Snowpacked Mountains", "Permafrost Highlands", "Clockwork City", "Bioforge Basin", "Crumbling Ruins", "Forgotten Temple", "Ancient Battlefield",
    "Archaeological Dig", "Agency Black Site", "Synthetic Biosphere", "Verdant Plains", "Blooming Valley", "Ironwood Deep", "Fungal Vales",
    "Bewitched Glen", "Netherbleak Hollow" "Wyrmscar Ridge" "Restricted Labratory", "Secret Lab", "Origin<UNKNOWN>", "Retired Military Base",
    "Condemned HydroPowerDam", "Monolithic Structures", "Classified Research Facilities"
]
ALL_HABITATS = sorted(list(set(_ALL_HABITATS_RAW)))


HABITATS_BY_TYPE: Dict[str, list] = {
    "Verdant": [
        "Oldgrowth Marsh", "Misty Glades", "Bewitched Glen", "Verdant Plains", "Blooming Valley", "Ironwood Deep", "Fungal Vales", "Thornveil Thicket",
        "Skyless MossWood", "Shattered Plateau", "Wyrmscar Ridge",
    ],
    "Pyro": [
        "Smoldering Flats", "Collapsed Magma Tubes", "Ancient Lavaflows", "Whispering Dunes", "Glass Caverns", "Obsidian Labyrinth", "Petrified Forest",
        "Ashlands", "Mt. Thermallia",
    ],
    "Geomorph": [
        "Crystalline Cave", "Petrified Forest", "Ancient Lavaflows", "Whispering Dunes", "Glass Caverns", "Thriving Reefs", "Crumbling Ruins",
        "Forgotten Temple", "Archaeological Dig"
    ],
    "Avian": [
        "Skybridge Peaks", "Frozen Steppe", "Whispering Dunes", "Glass Desert", "Verdant Plains", "Highlands", "Shattered Plateau", "Wyrmscar Ridge",
        "Yittrosian Forest",
    ],
    "Aquatic": [
        "Still Tidepools", "Thriving Reefs", "Sunless Abyss", "Alpine Lakes", "Moonlit Atolls", "Bioluminous Currents", "Violent Rapids",
        "Freshwater Springs", "Unyielding Cascades"
    ],
    "Beast": [
        "Crystalline Caverns", "Ennoan Grasslands", "Alpine Slopes", "Lunaglow Plateau", "Riverlands", "Skyless MossWood", "Still Tidepools",
        "Glass Desert", "Blooming Valley", "Ironwood Deep", "Fungal Vales", "Thornveil Thicket",
    ],
    "Mythic": [
        "Starfall Crater", "Celestial Spire", "Aurora Fields", "Twilight Basin", "Echoing Grotto", "Astral Terrace", "Synthetic Biosphere",
        "Origin<UNKNOWN>"
    ],
    "Insectoid": [
        "Twilight Basin", "Echoing Grotto", "Darkmist Chasm", "Netherbleak Hollow", "Whispering Dunes", "Alpine Lakes", "Petrified Forest",
        "Oldgrowth Marsh", "Misty Glades", "Skyless MossWood", "Still Tidepools", "Bioluminous Currents",
    ],
    "Dread": [
        "Dread Catacombs", "Gloomfen Bogs", "AshGlass Tombs", "Darkmist Chasm", "Netherbleak Hollow", "Abandoned Wastes", "Forgotten Boneyard",
        "Retired Military Base", "Monolithic Structures", "Skyless MossWood",
    ],
    "Electric": [
        "Power Plant", "Eroding Shipwreck", "Ghost Town", "Abandoned Village", "Restricted Labratory", "Concrete Jungle", "Retired Military Base",
        "Outdated Hydroelectric Dam", "Rusted Plane Wreckage"
    ],
    "Cryoform": [
        "Wild Tundra", "Ice Caps", "Snowcapped Peaks", "Frigid Icefields", "Sunless Extremes", "Snowpacked Mountains", "Permafrost Highlands"
    ],
    "Pugilist": [
        "Clockwork City", "Abandoned Workshop", "Bioforge Basin", "Crumbling Ruins", "Forgotten Temple", "Ancient Battlefield", "Archaeological Dig",
        "Secret Lab", "Agency Black Site", "Synthetic Biosphere", "Origin<UNKNOWN>"
    ],
    "Toxic": [
        "Still Tidepools", "Thriving Reefs", "Secret Lab", "Restricted Labratory", "Bewitched Glen", "Verdant Plains", "Blooming Valley",
        "Ironwood Deep", "Fungal Vales", "Darkmist Chasm", "Netherbleak Hollow"
    ],
    "Ancient": [
        "Bewitched Glen", "Darkmist Chasm", "Netherbleak Hollow" "Crumbling Ruins", "Forgotten Temple", "Synthetic Biosphere", "Abandoned Wastes",
        "Forgotten Boneyard", "Retired Military Base", "Monolithic Structures", "Dayless MossWood", "Wyrmscar Ridge"
    ],
    "Psychokinetic": [
        "Abandoned Village", "Restricted Labratory", "Secret Lab", "Crumbling Ruins", "Forgotten Temple", "Origin<UNKNOWN>", "Retired Military Base",
        "Condemned HydroPowerDam", "Ironwood Deep", "Monolithic Structures", "Dayless MossWood", "Ghost Town", "Classified Research Facilities",
    ],
    "Neutral": ALL_HABITATS,
    "Colorless": ALL_HABITATS
}
